import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class Curve {
	int a;
	int b; 
	int approx;
	
	double x;
	double y;
	
	int realX, realY;
	
	int scale;
	int onePiece;
	
	double angle = 0;

	ArrayList<Double> tPoints;
	
	int windowWidth = 1;
	int windowHeight = 1;
	int centerX, centerY;
	
	int centerXOffset = 0;
	int centerYOffset = 0;

	public Curve(int a, int b, int approx) {
		this.a = a;
		this.b = b;
		this.approx = approx;
		tPoints = new ArrayList<Double>();
		double plus = 2 * Math.PI / approx;
		for (double i = 0; i <= 2 * Math.PI; i += plus) {
			tPoints.add(i);
		}
	}
	
	public int getScale() {
		return scale;
	}

	public int getWindowWidth() {
		return windowWidth;
	}

	public int getWindowHeight() {
		return windowHeight;
	}

	public void setWindowWidth(int windowWidth) {
		this.windowWidth = windowWidth;
		this.setScale(scale);
	}

	public void setWindowHeight(int windowHeight) {
		this.windowHeight = windowHeight;
		this.setScale(scale);
	}

	public void setScale(int scale) {
		this.scale = scale;
		onePiece = Math.max(windowWidth, windowHeight) / (2 * scale);
		centerX = windowWidth / 2;
		centerY = windowHeight / 2;
	}

	public void paint(Graphics g) {
		g.setColor(Color.BLACK);
		/*	 �������� �� ���� f ������������ ����� rx, ry
			x_rotated = (x - rx) * cosf - (y - ry) * sinf + rx
			y_rotated = (x - rx) * sinf + (y - ry) * cosf + ry*/
		
		int realXPrev = 0, realYPrev = 0;
		
		int startX = 0, startY = 0;

		for (int i = 0; i < tPoints.size(); i++) {
			double val = tPoints.get(i);
			x = a * Math.sin(val);
			y = b * Math.cos(val);
			
			// rotation
			
			if (angle != 0) {
				double xn, yn;
				xn = x * Math.cos(angle) - y * Math.sin(angle);
				yn = x * Math.sin(angle) + y * Math.cos(angle);
				x = xn;
				y = yn;
			}
			
			// rotation
			
			double fractionalPart = (x % 1) * onePiece;
			int forSum = (int) fractionalPart;
			
			
			realX =(int) x/1 * onePiece + forSum;
			realX += centerX + centerXOffset;
			
			fractionalPart = (y % 1) * onePiece;
			forSum = (int) fractionalPart;
			
			realY = (int) y/1 * onePiece + forSum;
			realY += centerY + centerYOffset;
			
			//System.out.println(realX + " " + realY);
			
			if (i != 0) {
				g.drawLine(realXPrev, realYPrev, realX, realY);
			} else {
				startX = realX;
				startY = realY;
			}
			
			realXPrev = realX;
			realYPrev = realY;

		}
		
		g.drawLine(realXPrev, realYPrev, startX, startY);
		
		
	}
	
	public int getCenterXOffset() {
		return centerXOffset;
	}

	public int getCenterYOffset() {
		return centerYOffset;
	}

	public void setCenterXOffset(int centerXOffset) {
		this.centerXOffset = centerXOffset;
	}

	public void setCenterYOffset(int centerYOffset) {
		this.centerYOffset = centerYOffset;
	}

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public int getApprox() {
		return approx;
	}

	public void setA(int a) {
		this.a = a;
	}

	public void setB(int b) {
		this.b = b;
	}

	public void setApprox(int approx) {
		this.approx = approx;
		tPoints = new ArrayList<Double>();
		double plus = 2 * Math.PI / approx;
		for (double i = 0; i <= 2 * Math.PI; i += plus) {
			tPoints.add(i);
		}
	}
	
	public double getAngle() {
		return angle;
	}

	public void setAngle(double angle) {
		this.angle = angle;	
	}
}
