import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSlider;
import javax.swing.JTextField;

public class MyPanel extends JPanel implements ActionListener,  MouseWheelListener, MouseListener, KeyListener, MouseMotionListener {

	Font font;
	Curve curve;
	
	int approx = 10;
	int a = 1;
	int b = 1;
	double angle = 0;
	
	int centerXOffset = 0;
	int centerYOffset = 0;
	
	int currX = 0;
	int currY = 0;
	boolean isOffset = false;
	
	int wWidth = 586;
	int wHeight = 763;
	
	double tmpX, tmpY;
	
	long scale;
	
	public MyPanel() {
		
		curve = new Curve(a, b, approx);
		
		curve.setScale(10);
		
		font = new Font("Verdana", Font.PLAIN, 16);
		
	}
	
	public void paint(Graphics g) {
		
		if (getWidth() != wWidth || getHeight() != wHeight) {
			centerXOffset = 0;
			centerYOffset = 0;
			curve.setCenterXOffset(centerXOffset);
			curve.setCenterYOffset(centerYOffset);
			wWidth = getWidth();
			wHeight = getHeight();
			
			tmpX = curve.getXmax();
			tmpY = curve.getYmax();
			
			scale = Math.round( Math.min(tmpX, tmpY) ); 
			
			curve.setScale((int) scale);
			
			
		}
		
		curve.setWindowWidth(wWidth);
		curve.setWindowHeight(wHeight);
		
		//curve.setScale()
		
		super.paint(g);
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, getWidth(), getHeight());
		g.setColor(Color.BLACK);
		g.drawLine(getWidth() / 2 + centerXOffset, 0, getWidth() / 2 + centerXOffset, getHeight());
		g.drawLine(0, getHeight() / 2 + centerYOffset, getWidth(), getHeight() / 2 + centerYOffset);
		
		g.setFont(font);
		g.drawString("0", getWidth() / 2 + centerXOffset - 12, getHeight() / 2 + centerYOffset + 14);
		g.drawString("x", getWidth() - 15, getHeight() / 2 + centerYOffset + 14);
		g.drawString("y", getWidth() / 2 + centerXOffset - 12, 14);
		
		curve.paint(g);
		
		
	}
	
	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
		
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		isOffset = true;
		currX = e.getX();
		currY = e.getY();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
		if (isOffset) {
			centerXOffset += e.getX() - currX;
			centerYOffset += e.getY() - currY;
			isOffset = false;
		}
		curve.setCenterXOffset(centerXOffset);
		curve.setCenterYOffset(centerYOffset);

	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		// TODO Auto-generated method stub
		
		int amount = e.getWheelRotation();
		
		if (curve.getScale() + amount == 0) {
			curve.setScale(1);
		} else {
			curve.setScale(curve.getScale() + amount);
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		this.a = Program.getA();
		this.b = Program.getB();
		this.approx = Program.getApprox();
		this.angle = Program.getAngle();
		curve.setA(a);
		curve.setB(b);
		curve.setApprox(approx);
		curve.setAngle(angle);
		
		repaint();
		
	}

}
