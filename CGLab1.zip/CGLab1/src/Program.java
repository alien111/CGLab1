import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Program {
	
	static final int A_MIN = 1;
	static final int A_MAX = 100;
	static final int A_INIT = 10;
	
	static final int B_MIN = 1;
	static final int B_MAX = 100;
	static final int B_INIT = 10;
	
	static final int APPROX_MIN = 1;
	static final int APPROX_MAX = 100;
	static final int APPROX_INIT = 10;
	
	static final int ANGLE_MIN = -62831853;
	static final int ANGLE_MAX = 62831853;
	static final int ANGLE_INIT = 0;	
	
	static int a = 10;
	static int b = 10;
	static int approx = 10;
	static int angle = 0;

	public static void main(String[] args) {
		JFrame w = new JFrame();
		w.setLayout(new BorderLayout());
		w.setSize(800, 800);
		w.setLocation(10, 10);
		

		JSlider aSlider = new JSlider(JSlider.HORIZONTAL,
                A_MIN, A_MAX, A_INIT);		
		aSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				a = aSlider.getValue();
			}
		});
		
		aSlider.setMajorTickSpacing(10);
		aSlider.setMinorTickSpacing(1);
		aSlider.setPaintTicks(true);
		aSlider.setPaintLabels(true);
		
		JSlider bSlider = new JSlider(JSlider.HORIZONTAL,
                B_MIN, B_MAX, B_INIT);
		
		bSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				b = bSlider.getValue();
			}
		});

		bSlider.setMajorTickSpacing(10);
		bSlider.setMinorTickSpacing(1);
		bSlider.setPaintTicks(true);
		bSlider.setPaintLabels(true);
		
		JSlider approxSlider = new JSlider(JSlider.HORIZONTAL,
                APPROX_MIN, APPROX_MAX, APPROX_INIT);
		approxSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				approx = approxSlider.getValue();
			}
		});		
		
		approxSlider.setMajorTickSpacing(10);
		approxSlider.setMinorTickSpacing(1);
		approxSlider.setPaintTicks(true);
		approxSlider.setPaintLabels(true);
		
		JSlider angleSlider = new JSlider(JSlider.HORIZONTAL, ANGLE_MIN, ANGLE_MAX, ANGLE_INIT);
		angleSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				angle = angleSlider.getValue();
				//System.out.println(angle);
			}
		});
		
		JLabel labelA = new JLabel("A", JLabel.CENTER);
		JLabel labelB = new JLabel("B", JLabel.CENTER);
		JLabel labelApprox = new JLabel("Approximation", JLabel.CENTER);
		JLabel labelAngle = new JLabel("Angle(from -2*pi to 2*pi)", JLabel.CENTER);
		
		JPanel sliders = new JPanel(new GridLayout(8, 1));
		
		sliders.add(labelA);
		sliders.add(aSlider);
		sliders.add(labelB);
		sliders.add(bSlider);
		sliders.add(labelApprox);
		sliders.add(approxSlider);
		sliders.add(labelAngle);
		sliders.add(angleSlider);
		
		MyPanel p =  new MyPanel();
		w.add(p, BorderLayout.CENTER);
		w.add(sliders, BorderLayout.EAST);
		
		w.addKeyListener(p);
		
		p.addMouseWheelListener( p );
		p.addMouseListener(p);
		p.addMouseMotionListener(p);
		
		w.setVisible(true);
		
		
		Timer t = new Timer(1000/60, p);
		t.start();

	}

	public static double getAngle() {
		return angle / 10000000.0;
	}
	
	public static int getA() {
		return a;
	}

	public static int getB() {
		return b;
	}

	public static int getApprox() {
		return approx;
	}

}
